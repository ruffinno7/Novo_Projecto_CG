window.onload= function(){
    const config= {
        type: Phaser.AUTO,
        width: 800,
        height: 600,
        physics:{
            default: 'arcade',
            arcade:{
                gravity:{y:1000},
            }
        },
        scene: [Scena00]    
    }
    let game = new Phaser.Game(config);
}







    

 
