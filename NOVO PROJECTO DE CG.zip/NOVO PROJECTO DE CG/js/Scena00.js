class Scena00 extends Phaser.Scene{
    constructor (){
        super('Scena00');
    }

 preload(){
        this.load.image('sky', '../imagens/sky.png');
        this.load.image('chao', '../imagens/barra.png');
        this.load.image('barra', '../imagens/barra.png');
        this.load.image('star', '../imagens/star.png');
        this.load.image('taxi', '../imagens/taxi.png');
        this.load.image('barra2', '../imagens/fim.png');
        this.load.spritesheet('player', '../imagens/player2.png', {frameWidth: 30, frameHeight:47});
    }

     create(){

        
        this.fundo = this.add.image(0,0, 'sky').setOrigin(0)
        this.fundo.displayWidth = 800
        this.fundo.displayHeight = 600
        this.pontos = this.add.text(660,10, 'pontos: 0',{
            fontSize: '20px',
            fill: '#ececed'
        });
        this.chao= this.physics.add.staticGroup()
     //  Adicionar jogador
        this.player = this.physics.add.sprite(20, 400, 'player');
        this.player.setCollideWorldBounds(true);
        //  Adicionar carros 
        this.carro = this.physics.add.sprite(600, 1000, 'taxi');
        this.carro.setCollideWorldBounds(true);
        //  Adicionar estrelas 
        this.barra = this.physics.add.sprite(-265,600,'chao')
        this.barra.setScale(2,1)
        this.barra.setCollideWorldBounds(true);
        
        // Estrela
        this.star = this.physics.add.group({
            key:'star',
            repeat: 3,
            setXY: {
                x: 100,
                y: 100,
                stepX: 30,
            }
        });
        // fim
        this.barra2 = this.physics.add.image(0,1300,'barra2').setScale(0.02,1)
        this.barra2.setCollideWorldBounds(true);

     
   
        this.physics.add.collider(this.carro, this.player, pausar, null, this)
        this.physics.add.collider(this.barra, this.carro)
        this.physics.add.collider(this.barra, this.player)
        this.physics.add.collider(this.barra, this.star)
        this.physics.add.collider(this.barra, this.barra2)
        this.physics.add.collider(this.player, this.star,soma,null, this) 
        this.control = this.input.keyboard.createCursorKeys();
        this.physics.add.collider(this.carro, this.barra2,criarCarro,null, this) 

        let pontuacao = 0;
       function soma (player, item){
        console.log(pontuacao)
            item.disableBody(true, true);
            pontuacao = pontuacao + 1;
            this.pontos.setText('Pontos: ' + pontuacao)
            
        }
 
        function pausar(){
            this.physics.pause();
        }

        function criarCarro(carro, barra2){
            carro.disableBody(true,true);
            const novoCarro= this.physics.add.sprite(600, 1000, 'taxi'); 
            novoCarro.setCollideWorldBounds(true);
            novoCarro.setVelocityX(-150);
            this.physics.add.collider(this.barra, novoCarro)
    
        }
            
    }
    
    update(){
            if(this.control.left.isDown){
            this.player.setVelocityX(-150)
            } else if (this.control.up.isDown){
                this.player.setVelocityY(-150)
            } else if (this.control.right.isDown) {
                this.player.setVelocityX(150);
            }
            else{
                this.player.setVelocityX(0)
            }

            if(true){
                this.carro.setVelocityX(-180);
                
            }
    }
}